package com.almaystro.app;
import android.app.*;import android.os.*;import android.content.*;import android.view.*;import android.widget.*;
public class MainActivity extends Activity{public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);findViewById(R.id.start).setOnClickListener(v->startActivity(new Intent(this,RoleActivity.class)));}}
