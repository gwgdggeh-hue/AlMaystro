package com.almaystro.app;
import android.app.*;import android.os.*;import android.graphics.Color;import android.view.*;
public class SettingsActivity extends Activity{public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_settings);findViewById(R.id.dark).setOnClickListener(v->{boolean on=((android.widget.Switch)v).isChecked();getWindow().getDecorView().setBackgroundColor(on?Color.rgb(30,30,30):Color.WHITE);});}}
