package com.almaystro.app;
import android.app.*;import android.os.*;import android.content.*;
public class RoleActivity extends Activity{public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_role);findViewById(R.id.student).setOnClickListener(v->startActivity(new Intent(this,StudentActivity.class)));findViewById(R.id.teacher).setOnClickListener(v->startActivity(new Intent(this,TeacherActivity.class)));findViewById(R.id.settings).setOnClickListener(v->startActivity(new Intent(this,SettingsActivity.class)));}}
